/*    _      _ _
     /_\  __| (_)_ __  ___
    / _ \/ _` | | '  \/ -_)
   /_/ \_\__,_|_|_|_|_\___|

   scanexp.c:
   Dummy C file to help scanning symbols in header files.
*/

#define ADIME_SCAN_EXPORT
#include "adime.h"
#include "adime/adimeint.h"
