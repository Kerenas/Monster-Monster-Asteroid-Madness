class foo {foo() {}};
